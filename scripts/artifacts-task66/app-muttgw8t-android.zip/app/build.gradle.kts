plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }

android {
    namespace = "dev.ideaven.export.parityappmuttgw8t285e3e"
    compileSdk = 34
    defaultConfig {
        applicationId = "dev.ideaven.export.parityappmuttgw8t285e3e"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    buildTypes { release { isMinifyEnabled = false } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}

dependencies { implementation("androidx.appcompat:appcompat:1.7.0") }
