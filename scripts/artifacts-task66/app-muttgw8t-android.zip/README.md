# Parity App muttgw8t — Ideaven Android export (APK)

The app runs from `app/src/main/assets/index.html` inside a WebView.

## Build the APK

This project is preconfigured for `assembleDebug`.

- **CI (no local SDK):** push to GitHub — `.github/workflows/build-android.yml` builds `app-debug.apk` on every push and uploads it as an artifact.
- **Android Studio:** open this folder and Run.
- **Command line (SDK installed):** `gradle assembleDebug` — output at `app/build/outputs/apk/debug/`.

Prefer a Play Store bundle? Re-export with the AAB option (or run `gradle bundleDebug`).
